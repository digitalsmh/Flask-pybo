"""empty message

Revision ID: 3f7b56225237
Revises: c4ce4ba5fca9
Create Date: 2023-09-08 15:48:12.009415

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '3f7b56225237'
down_revision = 'c4ce4ba5fca9'
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
